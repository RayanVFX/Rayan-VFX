# Rayan VFX Website

A responsive static website ready for GitHub Pages, Cloudflare Pages or Netlify.

## 1. Before publishing

Open `index.html` and replace:

`YOUR-EMAIL@example.com`

with your real email address. It appears in the contact section and in the JavaScript email form.

## 2. Add your portfolio

Find the six elements containing:

`class="work"`

Replace each `href="#"` with the URL of the relevant YouTube video, TikTok, Google Drive preview, Vimeo page, etc.

You can also replace the placeholder text with thumbnails later.

## 3. Stripe

Do NOT put Stripe secret keys in this website.

For client payments, create Stripe Payment Links in Stripe and then change any button's `href` to your public Stripe Payment Link.

Example:

`<a class="btn red" href="YOUR_STRIPE_PAYMENT_LINK">Pay for this edit</a>`

The site does not pretend Stripe is connected until you add your real Payment Links.

## 4. Deploy

### GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Open Settings → Pages.
4. Select Deploy from a branch.
5. Select `main` and `/root`.
6. Save.
7. GitHub will give you a public website address.

### Cloudflare Pages
1. Create a Cloudflare account.
2. Go to Workers & Pages → Create.
3. Choose Pages and connect your Git repository, or upload the site.
4. Deploy.
5. Cloudflare gives you a public `.pages.dev` address.

### Netlify
1. Create a Netlify account.
2. Go to Add new project.
3. Choose Deploy manually.
4. Drag the website folder into the upload area.
5. Netlify gives you a public `.netlify.app` address.

## Important for Stripe

Your website should clearly show:
- what service you provide
- how clients can contact you
- pricing or how quotes work
- what clients are paying for
- your refund/cancellation terms once you have decided them

The template includes the service and pricing sections. Add your actual contact details and final business terms before using it commercially.
